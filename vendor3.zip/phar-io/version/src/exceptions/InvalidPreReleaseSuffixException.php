<?php declare(strict_types = 1);
namespace PharIo\Version;

class InvalidPreReleaseSuffixException extends \Exception implements Exception {
}
