<?php

namespace App\Http\Controllers;

use App\Models\Teknisi;
use App\Http\Requests\StoreTeknisiRequest;
use App\Http\Requests\UpdateTeknisiRequest;
use App\Models\Post;
use Illuminate\Http\Request;


class TeknisiController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
       
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Post $post)
    {
        return view('teknisi/create', compact('post'), [

            'title' => 'Beri Pesan'


        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
        
            'pesanteknisi' => 'required',
            'status' => 'required',
            'post_id' =>'required'

            
        ]);

       
        $validatedData['user_id'] = auth()->user()->id;
        Teknisi::create($validatedData);

        return redirect('/posts')->with('success', 'Pesan telah di submit');
   
    }

    /**
     * Display the specified resource.
     */
    public function show(Teknisi $teknisi)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Post $post)
    {
        $teknisi = Teknisi::where('post_id', $post->id)->first();
        return view('teknisi.edit',compact('post'),[
             'post' => $post,
            'title' => 'Beri Pesan',
            'teknisi' => $teknisi
        
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Post $post)
    {
        
        $validatedData = $request->validate([
        

            'pesanteknisi' => 'required',
            'status' => 'required',

     
        ]);

        $validatedData['user_id'] = auth()->user()->id;

        $teknisi = Teknisi::where('post_id', $post->id)->first();

        if($teknisi) {
            // Jika ditemukan, lakukan update data
            $teknisi->update($validatedData);
            return redirect('/posts')->with('success', 'Pesan telah Dikirim');
        } else {
            // Jika tidak ditemukan, lakukan redirect kembali ke halaman edit dengan pesan error
            return back()->with('error', 'Data teknisi tidak ditemukan');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Teknisi $teknisi)
    {
        //
    }


}
