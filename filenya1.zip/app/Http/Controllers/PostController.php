<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Category;
use App\Models\Teknisi;
use Illuminate\Http\Request;
use App\Http\Requests\UpdatePostRequest;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        $posts = Post::all();
        $teknisi = Teknisi::all(); 

        return view('posts',[
           'title' => 'Daftar Perangkat',
           'posts' => Post::where('user_id', auth()->user()->id)->latest()->paginate(2),
           'teknisi' => $teknisi

          
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('posts.create',[

            'title' => 'Perbaiki',
            'categories' => Category::all()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
        
            'hp' => 'required|max:255',
            'alamat' => 'required',
            'kerusakan' => 'required',
            'pesan' => 'required',
            'category_id' =>'required'

            
        ]);

        $validatedData['user_id'] = auth()->user()->id;

        Post::create($validatedData);

         return redirect('/posts')->with('success', 'Perangkatmu telah di submit');
    }
    

    /**
     * Display the specified resource.
     */
    public function show(Post $post)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Post $post)
    {

        return view('posts.edit',[

            'title' => 'Beri Pesan',
            'post' => $post,
            'categories' => Category::all()
        ]);
        
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Post $post)
    {
        $validatedData = $request->validate([
        

            'pesan' => 'required'
     
        ]);

        $validatedData['user_id'] = auth()->user()->id;

        Post::where('id', $post->id)
             ->update($validatedData);

         return redirect('/posts')->with('success', 'Pesan telah Dikirim');

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Post $post)
    {
        Post::destroy($post->id);

        return redirect('/posts')->with('success', 'Postingan telah di hapus');
    }
}
