<?php

use App\Models\User;
use App\Models\Teknisi;
use App\Models\Category;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\TeknisiController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\DashboardController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('home', [
    "title"=> "Home"


    ]);
});

Route::get('/about', function () {
    return view('about',[
        "title"=> "About"
    ]);
});



Route::get('/sparepart', function () {
    return view('sparepart',[
        "title"=> "SparePart"

    ]);
});

Route::get('/brand', function () {
    return view('brand',[
        "title"=> "Brand"

    ]);
});


Route::get('/posts', [PostController::class, 'index'])->middleware('auth');

Route::get('/categories/{category:slug}', function(Category $category) {

    $teknisi = Teknisi::all(); 
    $posts = $category->posts()->paginate(2);
  
    return view('category', [
    'title' => $category->merek,
    'posts' => $posts,
    'category' => $category->merek,
    'teknisi' => $teknisi,
    
    
    ]);
})->middleware('auth', 'admin');

Route::get('/user/{user:email}', function(User $user) {

    $teknisi = Teknisi::all(); 

    $posts = $user->posts()->paginate(2);

    return view('posts', [
    'title' => $user->nama,
    'posts' => $posts,
    'teknisi' => $teknisi
    ]);
})->middleware('auth');


Route::get('/login', [LoginController::class, 'index'])->name('login')->middleware('guest');
Route::post('/login', [LoginController::class, 'authenticate']);
Route::post('/logout', [LoginController::class, 'logout']);

Route::get('/register', [RegisterController::class, 'index'])->middleware('guest');
Route::post('/register', [RegisterController::class, 'store']);

Route::get('/dashboard', [DashboardController::class, 'index'])->middleware('auth');

Route::resource('/posts', PostController::class)->middleware('auth');

Route::get('/posts/{post}/teknisi/create', [TeknisiController::class, 'create'])->name('posts.teknisi.create');
Route::get('/posts/{post}/teknisi/edit', [TeknisiController::class, 'edit'])->name('posts.teknisi.edit');
Route::put('/posts/{post}/teknisi', [TeknisiController::class, 'update'])->name('posts.teknisi.update');
Route::resource('/posts/teknisi', TeknisiController::class)->middleware('auth');
Route::post('/posts/{post}/teknisi', [TeknisiController::class, 'store'])->name('posts.teknisi.store');














