@extends('layouts.main')

@section('container')
<div class="row justify-content-center background-login">
    <div class="col-md-5">

        <main class="form-registration w-100 m-auto">
            <form action="{{ route('posts.teknisi.update', ['post' => $post->id]) }}" method="post">
              @method('put')
              @csrf
              <center><img class="mb-4 box-with-shadow" src="img/logo.jpg" alt="" width="100px"></center>
              <center><h1 class="h3 mb-3 warna-text text-with-shadow mt-5">Update Pesan</h1></center>
              
              <div class="form-floating box-with-shadow">
                <input type="text" name="pesanteknisi" class="form-control rounded-top @error('pesanteknisi') is-invalid @enderror" id="floatingInput" placeholder="pesanteknisi" value="{{ old('pesanteknisi') }}">
                <label for="floatingInput">Pesan untuk User</label>
                @error('Pesan Teknisi')
<div class="invalid-feedback">
{{ $message }}
</div>
@enderror
              </div>

              <div class="form-floating box-with-shadow">
                <input type="text" name="status" class="form-control rounded-bottom @error('status') is-invalid @enderror" id="floatingInput" placeholder="status" value="{{ old('status', $teknisi->status) }}">
                <label for="floatingInput">Status Perangkat</label>
                @error('Status')
<div class="invalid-feedback">
{{ $message }}
</div>
@enderror
              </div>
                       
                <button class="button btn btn-dark w-100 py-2 box-with-shadow mt-2" type="submit">Kirim</button>
              </form>
            </main>



    </div>
</div>
    
@endsection