@extends('layouts.main')

@section('container')
<div class="row justify-content-center background-login">
    <div class="col-md-5">

        <main class="form-registration w-100 m-auto">
            <form action="{{ route('posts.teknisi.store', ['post' => $post->id]) }}" method="post">
              @csrf
              <center><img class="mb-4 box-with-shadow" src="img/logo.jpg" alt="" width="100px"></center>
              <center><h1 class="h3 mb-3 warna-text text-with-shadow mt-5">Beri Pesan ke User</h1></center>
              <input type="hidden" name="post_id" value="{{ $post->id }}">
              <div class="form-floating box-with-shadow">
                <input type="text" name="pesanteknisi" class="form-control rounded-top @error('pesanteknisi') is-invalid @enderror" id="floatingInput" placeholder="pesanteknisi" value="{{ old('pesanteknisi') }}">
                <label for="floatingInput">Pesan</label>
                @error('Pesan')
<div class="invalid-feedback">
{{ $message }}
</div>
@enderror
              </div>

              <div class="form-floating box-with-shadow">
                <input type="text" name="status" class="form-control rounded-bottom @error('status') is-invalid @enderror" id="floatingInput" placeholder="status" value="{{ old('status') }}">
                <label for="floatingInput">Status Perangkat</label>
                @error('Status')
<div class="invalid-feedback">
{{ $message }}
</div>
@enderror
              </div>

                       
                <button class="button btn btn-dark w-100 py-2 box-with-shadow mt-2" type="submit">Selesai</button>
              </form>
            </main>



    </div>
</div>
    
@endsection