@extends('layouts.main')

@section('container')
<h1>&nbsp;</h1>
<h1>&nbsp;</h1>
<center><img src="img/logo.jpg" alt="logo" width="200px" class="mt-2 box-with-shadow"></center>
<center><h2 class="mt-3 warna-text text-with-shadow">"we fix it, we will do it rapidly"</h2></center>
@endsection

