@extends('layouts/main')

@section('container')

@foreach ($posts as $post)

<div class="col-lg">
    <div class="card m-2 navbar-custom"  style="height:100%;">
        <div class="card-body ">
            <h6 class="text-primary-emphasis">{{ $post["created_at"] }}</h6>
            <h4 class="card-title">{{ $post["hp"] }}</h4>
            <h6 class="card-text">Nama User : {{ $post->user->nama }}</h6>
            <h6 class="card-text">Brand  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: {{ $post->category->merek }}</h6>
            <h6 class="card-text">Kerusakan &nbsp;: {{ $post["kerusakan"] }}</h6>
            <h6 class="card-text">Alamat &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  : {{ $post["alamat"] }}</h6>
            <h6 class="card-text">Pesan dari User : {{ $post["pesan"] }}</h6>
            <h6 class="text-primary-emphasis">Pesan di update pada {{ $post["updated_at"] }}</h6>
            @foreach ($teknisi as $t)
            @if ($t->post_id == $post->id)
            <h6 class="card-text">Pesan dari Teknisi: {{ $t->pesanteknisi }}</h6>
            <h6 class="card-text">Status: {{ $t->status }}</h6>
            <h6 class="text-primary-emphasis">Status dan Pesan Teknisi di update pada {{ $t["updated_at"] }}</h6>
            @endif
            
            @endforeach 
            
            
            @if ($teknisi->where('post_id', $post->id)->isNotEmpty())
            <button class="badge border-0"><a href="/posts/{{ $post->id }}/teknisi/edit" class="btn btn-light warna-text ">Update Pesan & Status &nbsp; <i class="bi bi-box-arrow-up"></i></a></button>
        @else
            <button class="badge border-0"><a href="/posts/{{ $post->id }}/teknisi/create" class="btn btn-light warna-text ">Tulis Pesan & Status Baru &nbsp; <i class="bi bi-plus-square"></i></a></button>
        @endif

            <form action="/posts/{{ $post->id }}" method="post" class="d-inline">
                @method('delete')
                @csrf
            <button class="badge border-0" onclick="return confirm('Apakah kamu yakin?')"><a class="btn btn-light "><i class="bi bi-trash"></i></a></button>
            </form>


        </div>
    </div>
    </div>

@endforeach

<div class="d-flex justify-content-center"> {{  $posts->links() }} </div>

@endsection