@extends('layouts.main')

@section('container')
<div class="row justify-content-center background-login">
    <div class="col-md-4">

      
      <main class="form-signin w-100 m-auto">
        <form action="/login" method="post">
          @csrf
          <center><img class="mb-4 box-with-shadow" src="img/logo.jpg" alt="" width="100px"></center>
          <center><h1 class="h3 mb-3 warna-text text-with-shadow">Silahkan Login</h1></center>
          
          @if(session()->has('loginError'))
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
               {{ session('loginError') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
              <div class="form-floating box-with-shadow">
                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" id="email" placeholder="name@example.com" required value="{{ old('email') }}" autofocus>
                <label for="floatingInput">Email</label>
                @error('email')
                <div class="invalid-feedback">
                {{ $message }}
                </div>
                @enderror
              </div>
              <div class="form-floating box-with-shadow">
                <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" id="password" placeholder="Password" required>
                <label for="floatingPassword">Password</label>
                @error('password')
                <div class="invalid-feedback">
                {{ $message }}
                </div>
                @enderror
              </div>
          
        
              <button class="button btn btn-dark w-100 py-2 box-with-shadow " type="submit">Login</button>
            
            </form>
<small>Belum punya akun? <a href="/register">Buat Akun Sekarang!</a></small>
          </main>


    </div>
</div>
    
@endsection