@extends('layouts.main')

@section('container')
<div class="row justify-content-center background-login">
    <div class="col-md-5">

        <main class="form-registration w-100 m-auto">
            <form action="/register" method="post">
              @csrf
              <center><img class="mb-4 box-with-shadow" src="img/logo.jpg" alt="" width="100px"></center>
              <center><h1 class="h3 mb-3 warna-text text-with-shadow">Buat Akun</h1></center>
              <div class="form-floating box-with-shadow">
                <input type="text" name="nama" class="form-control rounded-top @error('nama') is-invalid @enderror" id="floatingInput" placeholder="nama" value="{{ old('nama') }}">
                <label for="floatingInput">Nama</label>
                @error('nama')
<div class="invalid-feedback">
{{ $message }}
</div>
@enderror
              </div>
              <div class="form-floating box-with-shadow">
                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" id="floatingInput" placeholder="name@example.com" required value="{{ old('email') }}">
                <label for="floatingInput">Email</label>
                @error('email')
<div class="invalid-feedback">
{{ $message }}
</div>
@enderror
              </div>
              <div class="form-floating box-with-shadow ">
                <input type="password" name="password" class="form-control rounded-bottom @error('password') is-invalid @enderror" id="floatingPassword" placeholder="password">
                <label for="floatingPassword">Password</label>
                @error('password')
<div class="invalid-feedback">
{{ $message }}
</div>
@enderror
              </div>
                
        
              
                <button class="button btn btn-dark w-100 py-2 box-with-shadow mt-2" type="submit">Buat Akun</button>
              </form>
            </main>
          <small>Sudah punya akun? <a href="/login">Login Sekarang!</a></small>


    </div>
</div>
    
@endsection