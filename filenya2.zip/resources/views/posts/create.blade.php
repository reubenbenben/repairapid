@extends('layouts.main')

@section('container')
<div class="row justify-content-center background-login">
    <div class="col-md-5">

        <main class="form-registration w-100 m-auto">
            <form action="/posts" method="post">
              @csrf
              <center><img class="mb-4 box-with-shadow" src="img/logo.jpg" alt="" width="100px"></center>
              <center><h1 class="h3 mb-3 warna-text text-with-shadow">Input Data Perangkatmu</h1></center>
              <div class="form-floating box-with-shadow">
                <input type="text" name="hp" class="form-control rounded-top @error('hp') is-invalid @enderror" id="floatingInput" placeholder="hp" value="{{ old('hp') }}">
                <label for="floatingInput">Tipe Perangkat</label>
                @error('Tipe Perangkat')
<div class="invalid-feedback">
{{ $message }}
</div>
@enderror
              </div>
              <div class="form-floating box-with-shadow">
                <input type="text" name="alamat" class="form-control  @error('alamat') is-invalid @enderror" id="floatingInput" placeholder="alamat" value="{{ old('alamat') }}">
                <label for="floatingInput">Alamat</label>
                @error('Alamat')
<div class="invalid-feedback">
{{ $message }}
</div>
@enderror
              </div>
              <div class="form-floating box-with-shadow">
                <input type="text" name="kerusakan" class="form-control  @error('kerusakan') is-invalid @enderror" id="floatingInput" placeholder="kerusakan" value="{{ old('kerusakan') }}">
                <label for="floatingInput">Kerusakan</label>
                @error('Kerusakan')
<div class="invalid-feedback">
{{ $message }}
</div>
@enderror
              </div>
              <div class="form-floating box-with-shadow">
                <input type="text" name="pesan" class="form-control rounded-bottom @error('pesan') is-invalid @enderror" id="floatingInput" placeholder="pesan" value="{{ old('pesan') }}">
                <label for="floatingInput">Pesan untuk Teknisi</label>
                @error('Pesan untuk Teknisi')
<div class="invalid-feedback">
{{ $message }}
</div>
@enderror
              </div>

              <label for="category" class="form-label mt-3">Brand</label>
              <div class=" box-with-shadow">
<select class="form-select" name="category_id">
    @foreach ($categories as $category)
@if (old('category_id') == $category->id)
<option value="{{ $category->id }}" selected>{{ $category->merek }}</option>
@else
<option value="{{ $category->id }}">{{ $category->merek }}</option>
@endif
  @endforeach
</select>
              </div>
              


                          
                <button class="button btn btn-dark w-100 py-2 box-with-shadow mt-2" type="submit">Selesai</button>
              </form>
            </main>



    </div>
</div>
    
@endsection