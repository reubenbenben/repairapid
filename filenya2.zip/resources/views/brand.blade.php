@extends('layouts.main')

@section('container')
<center><img src="/img/iphone.jpg" alt="" width="300px" class="box-with-shadow">
<h1 class="warna-text text-with-shadow mt-1">Iphone</h1>
<p>&nbsp;</p>
<img src="/img/samsung.jpg" alt="" width="300px" class="box-with-shadow">
<h1 class="warna-text text-with-shadow mt-1">Samsung</h1>
<p>&nbsp;</p>
<img src="/img/xiaomi.jpg" alt="" width="300px" class="box-with-shadow">
<h1 class="warna-text text-with-shadow mt-1">Xiaomi</h1>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h4 class="warna-text text-with-shadow ">Brand Lain Coming Soon!</h4></center>

@endsection