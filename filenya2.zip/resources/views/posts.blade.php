@extends('layouts/main')

@section('container')
<h6 class="warna-text">Note: Jika anda baru menginput perangkat, maka belum ada status dan pesan teknisi. Harap bersabar sampai teknisi kami memberikan pesan dan mengupdate status perangkat anda. Terimakasih</h6>

@if(session()->has('success'))
<div class="alert alert-success" role="alert">
{{ session( 'success') }} 
</div>
@endif
@can('tkiphone')
<button class="badge border-0"><a href="/categories/iphone" class="btn btn-light warna-text ">Kembali</a></button>
@endcan
@can('tkxiaomi')
<button class="badge border-0"><a href="/categories/xiaomi" class="btn btn-light warna-text ">Kembali</a></button>
@endcan
@can('tksamsung')
<button class="badge border-0"><a href="/categories/samsung" class="btn btn-light warna-text ">Kembali</a></button>
@endcan
@foreach ($posts as $post)

<div class="col-lg">
    <div class="card m-2 navbar-custom"  style="height:100%;">
        <div class="card-body ">
            <h6 class="text-primary-emphasis">{{ $post["created_at"] }}</h6>
            <h4 class="card-title">{{ $post["hp"] }}</h4> 
            <h6 class="card-text">Nama User : {{ $post->user->nama }}</h6>
            <h6 class="card-text">Brand  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: {{ $post->category->merek }}</h6>
            <h6 class="card-text">Kerusakan &nbsp;: {{ $post["kerusakan"] }}</h6>
            <h6 class="card-text">Alamat &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  : {{ $post["alamat"] }}</h6>
            <h6 class="card-text">Pesan dari User : {{ $post["pesan"] }}</h6>
            <h6 class="text-primary-emphasis">Pesan di update pada {{ $post["updated_at"] }}</h6>

            @foreach ($teknisi as $t)
            @if ($t->post_id == $post->id)
            <h6 class="card-text">Pesan dari Teknisi : {{ $t->pesanteknisi }}</h6>
            <h6 class="card-text">Status : {{ $t->status }}</h6>
            <h6 class="text-primary-emphasis">Status dan Pesan Teknisi di update pada {{ $t["updated_at"] }}</h6>
            @endif
            @endforeach 

            <button class="badge border-0"><a href="/posts/{{ $post->id }}/edit" class="btn btn-light warna-text ">Tulis Pesan &nbsp; <i class="bi bi-chat-square-dots"></i></a></button>
        </div>
    </div>
    </div>
    @endforeach

<div class="d-flex justify-content-center"> {{  $posts->links() }} </div>
@endsection