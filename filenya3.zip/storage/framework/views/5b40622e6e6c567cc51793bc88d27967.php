

<?php $__env->startSection('container'); ?>
<h1>&nbsp;</h1>
<h1>&nbsp;</h1>
<center><img src="img/logo.jpg" alt="logo" width="200px" class="mt-2 box-with-shadow"></center>
<center><h2 class="mt-3 warna-text text-with-shadow">"we fix it, we will do it rapidly"</h2></center>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\repairapid\repair-rapid\resources\views/home.blade.php ENDPATH**/ ?>