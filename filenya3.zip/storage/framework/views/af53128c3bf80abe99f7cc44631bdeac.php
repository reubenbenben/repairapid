

<?php $__env->startSection('container'); ?>
<h1 class="warna-text text-with-shadow ">About</h1>
<p class=" warna-text">RepaiRapid adalah apikasi yang berperan sebagai layanan servis <br> smartphone
    pihak ketiga yang bertujuan untuk
    menghubungkan <br> teknisi ahli dan
    customer dengan mudah, murah
    dan juga aman.</p>

    <h5 class=" warna-text">"harap login terlebih dahulu agar dapat mengakses Menu"</h5>
    
    <div class="row mt-2">
        <center><h3 class="warna-text text-with-shadow mt-3">Anggota Kelompok</h3></center>
        <div class="col-lg">
    <img src="/img/ili.jpg" alt="" width="300px" class="box-with-shadow">
    <h5 class="warna-text text-with-shadow mt-2">M.Firli Raudho Rizki "Penganalisa"</h5>
    <h5 class="warna-text text-with-shadow ">NIM : 03041282328030 </h5></div>
    <div class="col-lg">
    <img src="/img/iqbal.jpg" alt="" width="300px" class="box-with-shadow">
    <h5 class="warna-text text-with-shadow mt-2">M.Iqbal Fauzan "Designer"</h5>
    <h5 class="warna-text text-with-shadow ">NIM : 03041282328046 </h5></div>
    <div class="col-lg">
        <img src="/img/beben.jpg" alt="" width="300px" class="box-with-shadow">
        <h5 class="warna-text text-with-shadow mt-2">M. Reuben Athallah 'Progammer'</h5>
        <h5 class="warna-text text-with-shadow ">NIM : 03041282328048 </h5></div>
        <div class="col-lg">
            <img src="/img/farhan.jpg" alt="" width="300px" class="box-with-shadow">
            <h5 class="warna-text text-with-shadow mt-2">Muh Farhan Haidir 'Dokumentator'</h5>
            <h5 class="warna-text text-with-shadow ">NIM : 03041282328062 </h5></div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\repairapid\repair-rapid\resources\views/about.blade.php ENDPATH**/ ?>