

<?php $__env->startSection('container'); ?>

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="col-lg">
    <div class="card m-2 navbar-custom"  style="height:100%;">
        <div class="card-body ">
            <h6 class="text-primary-emphasis"><?php echo e($post["created_at"]); ?></h6>
            <h4 class="card-title"><?php echo e($post["hp"]); ?></h4>
            <h6 class="card-text">Nama User : <?php echo e($post->user->nama); ?></h6>
            <h6 class="card-text">Brand  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <?php echo e($post->category->merek); ?></h6>
            <h6 class="card-text">Kerusakan &nbsp;: <?php echo e($post["kerusakan"]); ?></h6>
            <h6 class="card-text">Alamat &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  : <?php echo e($post["alamat"]); ?></h6>
            <h6 class="card-text">Pesan dari User : <?php echo e($post["pesan"]); ?></h6>
            <h6 class="text-primary-emphasis">Pesan di update pada <?php echo e($post["updated_at"]); ?></h6>
            <?php $__currentLoopData = $teknisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($t->post_id == $post->id): ?>
            <h6 class="card-text">Pesan dari Teknisi: <?php echo e($t->pesanteknisi); ?></h6>
            <h6 class="card-text">Status: <?php echo e($t->status); ?></h6>
            <h6 class="text-primary-emphasis">Status dan Pesan Teknisi di update pada <?php echo e($t["updated_at"]); ?></h6>
            <?php endif; ?>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            
            
            <?php if($teknisi->where('post_id', $post->id)->isNotEmpty()): ?>
            <button class="badge border-0"><a href="/posts/<?php echo e($post->id); ?>/teknisi/edit" class="btn btn-light warna-text ">Update Pesan & Status &nbsp; <i class="bi bi-box-arrow-up"></i></a></button>
        <?php else: ?>
            <button class="badge border-0"><a href="/posts/<?php echo e($post->id); ?>/teknisi/create" class="btn btn-light warna-text ">Tulis Pesan & Status Baru &nbsp; <i class="bi bi-plus-square"></i></a></button>
        <?php endif; ?>

            <form action="/posts/<?php echo e($post->id); ?>" method="post" class="d-inline">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
            <button class="badge border-0" onclick="return confirm('Apakah kamu yakin?')"><a class="btn btn-light "><i class="bi bi-trash"></i></a></button>
            </form>


        </div>
    </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="d-flex justify-content-center"> <?php echo e($posts->links()); ?> </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\repairapid\repair-rapid\resources\views/category.blade.php ENDPATH**/ ?>