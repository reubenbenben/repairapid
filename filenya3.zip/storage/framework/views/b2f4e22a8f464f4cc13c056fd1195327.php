

<?php $__env->startSection('container'); ?>
<h1 class="warna-text text-with-shadow ">Perkiraan Harga Sparepart Iphone</h1>
<h5 class=" warna-text">Pro Max Series</h5>
    <p class=" warna-text ">Layar Depan = Rp800.000 - Rp1.500.000<br>
    LCD = Rp2.000.000 - Rp6.000.000<br>
    BackGlass = Rp200.000 - Rp600.000<br>
    MainBoard = Rp4.000.000 - Rp8.000.000<br>
    Battery = Rp200.000 - Rp600.000<br>
    Colokan = Rp100.000 - Rp400.000<br>
</p>
<h5 class=" warna-text">Pro Series</h5>
    <p class=" warna-text ">Layar Depan = Rp800.000 - Rp1.500.000<br>
    LCD = Rp2.000.000 - Rp6.000.000<br>
    BackGlass = Rp200.000 - Rp600.000<br>
    MainBoard = Rp4.000.000 - Rp8.000.000<br>
    Battery = Rp200.000 - Rp600.000<br>
    Colokan = Rp100.000 - Rp400.000<br>
</p>
</p>
<h5 class=" warna-text">Seri Nomor</h5>
    <p class=" warna-text ">Layar Depan = Rp100.000 - Rp800.000<br>
    LCD = Rp1.000.000 - Rp3.000.000<br>
    BackGlass = Rp200.000 - Rp600.000<br>
    MainBoard = Rp1.000.000 - Rp3.000.000<br>
    Battery = Rp100.000 - Rp500.000<br>
    Colokan = Rp100.000 - Rp400.000<br>
</p>

<h5 class=" warna-text">Ipad Series</h5>
    <p class=" warna-text ">Layar Depan = Rp200.000 - Rp800.000<br>
    LCD = Rp2.000.000 - Rp3.000.000<br>
    BackGlass = Rp200.000 - Rp600.000<br>
    MainBoard = Rp1.000.000 - Rp3.000.000<br>
    Battery = Rp100.000 - Rp500.000<br>
    Colokan = Rp100.000 - Rp400.000<br>
</p>

<h1 class="warna-text text-with-shadow ">Perkiraan Harga Sparepart Samsung</h1>
<h5 class=" warna-text">Fold/Flip Series</h5>
    <p class=" warna-text ">Layar Depan = Rp500.000 - Rp1.000.000<br>
    LCD = Rp2.000.000 - Rp4.000.000<br>
    BackGlass = Rp200.000 - Rp600.000<br>
    MainBoard = Rp3.000.000 - Rp4.000.000<br>
    Battery = Rp200.000 - Rp600.000<br>
    Colokan = Rp100.000 - Rp400.000<br>
</p>
<h5 class=" warna-text">Flagship "S Series, Note Series, Ultra Series"</h5>
    <p class=" warna-text ">Layar Depan = Rp500.000 - Rp1.000.000<br>
    LCD = Rp2.000.000 - Rp4.000.000<br>
    BackGlass = Rp200.000 - Rp600.000<br>
    MainBoard = Rp3.000.000 - Rp4.000.000<br>
    Battery = Rp200.000 - Rp600.000<br>
    Colokan = Rp100.000 - Rp400.000<br>
</p>
<h5 class=" warna-text">MidRange - Entry "A Series, M Series"</h5>
    <p class=" warna-text ">Layar Depan = Rp100.000 - Rp800.000<br>
    LCD = Rp1.000.000 - Rp3.000.000<br>
    BackGlass = Rp200.000 - Rp600.000<br>
    MainBoard = Rp1.000.000 - Rp3.000.000<br>
    Battery = Rp100.000 - Rp500.000<br>
    Colokan = Rp100.000 - Rp400.000<br>
</p>

<h5 class=" warna-text">Tab Series</h5>
    <p class=" warna-text ">Layar Depan = Rp200.000 - Rp800.000<br>
    LCD = Rp2.000.000 - Rp3.000.000<br>
    BackGlass = Rp200.000 - Rp600.000<br>
    MainBoard = Rp1.000.000 - Rp3.000.000<br>
    Battery = Rp100.000 - Rp500.000<br>
    Colokan = Rp100.000 - Rp400.000<br>
</p>

<h1 class="warna-text text-with-shadow ">Perkiraan Harga Sparepart Xiaomi</h1>
<h5 class=" warna-text">MI Series</h5>
    <p class=" warna-text ">Layar Depan = Rp500.000 - Rp1.000.000<br>
    LCD = Rp2.000.000 - Rp4.000.000<br>
    BackGlass = Rp200.000 - Rp600.000<br>
    MainBoard = Rp3.000.000 - Rp4.000.000<br>
    Battery = Rp200.000 - Rp600.000<br>
    Colokan = Rp100.000 - Rp400.000<br>
</p>
<h5 class=" warna-text">MI "T" Series</h5>
    <p class=" warna-text ">Layar Depan = Rp500.000 - Rp1.000.000<br>
    LCD = Rp2.000.000 - Rp4.000.000<br>
    BackGlass = Rp200.000 - Rp600.000<br>
    MainBoard = Rp3.000.000 - Rp4.000.000<br>
    Battery = Rp200.000 - Rp600.000<br>
    Colokan = Rp100.000 - Rp400.000<br>
</p>
<h5 class=" warna-text">MidRange - Entry "Redmi Note, Redmi Series"</h5>
    <p class=" warna-text ">Layar Depan = Rp100.000 - Rp800.000<br>
    LCD = Rp1.000.000 - Rp3.000.000<br>
    BackGlass = Rp200.000 - Rp600.000<br>
    MainBoard = Rp1.000.000 - Rp3.000.000<br>
    Battery = Rp100.000 - Rp500.000<br>
    Colokan = Rp100.000 - Rp400.000<br>
</p>

<h5 class=" warna-text">Xiaomi Pad Series</h5>
    <p class=" warna-text ">Layar Depan = Rp200.000 - Rp800.000<br>
    LCD = Rp2.000.000 - Rp3.000.000<br>
    BackGlass = Rp200.000 - Rp600.000<br>
    MainBoard = Rp1.000.000 - Rp3.000.000<br>
    Battery = Rp100.000 - Rp500.000<br>
    Colokan = Rp100.000 - Rp400.000<br>
</p>

<h5>brand lain coming soon!</h5>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\repairapid\repair-rapid\resources\views/sparepart.blade.php ENDPATH**/ ?>