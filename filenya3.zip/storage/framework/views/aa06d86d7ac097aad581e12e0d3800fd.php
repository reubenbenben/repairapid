

<?php $__env->startSection('container'); ?>
<div class="row justify-content-center background-login">
    <div class="col-md-5">

        <main class="form-registration w-100 m-auto">
            <form action="/posts" method="post">
              <?php echo csrf_field(); ?>
              <center><img class="mb-4 box-with-shadow" src="img/logo.jpg" alt="" width="100px"></center>
              <center><h1 class="h3 mb-3 warna-text text-with-shadow">Input Data Perangkatmu</h1></center>
              <div class="form-floating box-with-shadow">
                <input type="text" name="hp" class="form-control rounded-top <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingInput" placeholder="hp" value="<?php echo e(old('hp')); ?>">
                <label for="floatingInput">Tipe Perangkat</label>
                <?php $__errorArgs = ['Tipe Perangkat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="invalid-feedback">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-floating box-with-shadow">
                <input type="text" name="alamat" class="form-control  <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingInput" placeholder="alamat" value="<?php echo e(old('alamat')); ?>">
                <label for="floatingInput">Alamat</label>
                <?php $__errorArgs = ['Alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="invalid-feedback">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-floating box-with-shadow">
                <input type="text" name="kerusakan" class="form-control  <?php $__errorArgs = ['kerusakan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingInput" placeholder="kerusakan" value="<?php echo e(old('kerusakan')); ?>">
                <label for="floatingInput">Kerusakan</label>
                <?php $__errorArgs = ['Kerusakan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="invalid-feedback">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-floating box-with-shadow">
                <input type="text" name="pesan" class="form-control rounded-bottom <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingInput" placeholder="pesan" value="<?php echo e(old('pesan')); ?>">
                <label for="floatingInput">Pesan untuk Teknisi</label>
                <?php $__errorArgs = ['Pesan untuk Teknisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="invalid-feedback">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <label for="category" class="form-label mt-3">Brand</label>
              <div class=" box-with-shadow">
<select class="form-select" name="category_id">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(old('category_id') == $category->id): ?>
<option value="<?php echo e($category->id); ?>" selected><?php echo e($category->merek); ?></option>
<?php else: ?>
<option value="<?php echo e($category->id); ?>"><?php echo e($category->merek); ?></option>
<?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
              </div>
              


                          
                <button class="button btn btn-dark w-100 py-2 box-with-shadow mt-2" type="submit">Selesai</button>
              </form>
            </main>



    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\repairapid\repair-rapid\resources\views/posts/create.blade.php ENDPATH**/ ?>