

<?php $__env->startSection('container'); ?>
<div class="row justify-content-center background-login">
    <div class="col-md-5">

        <main class="form-registration w-100 m-auto">
            <form action="<?php echo e(route('posts.teknisi.update', ['post' => $post->id])); ?>" method="post">
              <?php echo method_field('put'); ?>
              <?php echo csrf_field(); ?>
              <center><img class="mb-4 box-with-shadow" src="img/logo.jpg" alt="" width="100px"></center>
              <center><h1 class="h3 mb-3 warna-text text-with-shadow mt-5">Update Pesan</h1></center>
              
              <div class="form-floating box-with-shadow">
                <input type="text" name="pesanteknisi" class="form-control rounded-top <?php $__errorArgs = ['pesanteknisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingInput" placeholder="pesanteknisi" value="<?php echo e(old('pesanteknisi')); ?>">
                <label for="floatingInput">Pesan untuk User</label>
                <?php $__errorArgs = ['Pesan Teknisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="invalid-feedback">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-floating box-with-shadow">
                <input type="text" name="status" class="form-control rounded-bottom <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="floatingInput" placeholder="status" value="<?php echo e(old('status', $teknisi->status)); ?>">
                <label for="floatingInput">Status Perangkat</label>
                <?php $__errorArgs = ['Status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="invalid-feedback">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
                       
                <button class="button btn btn-dark w-100 py-2 box-with-shadow mt-2" type="submit">Kirim</button>
              </form>
            </main>



    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\repairapid\repair-rapid\resources\views/teknisi/edit.blade.php ENDPATH**/ ?>