

<?php $__env->startSection('container'); ?>


    <div class="row">

        <div class="col-lg">
        <div class="card m-2"  style="height:250px;">
            <div class="card-body">
                <h5 class="card-title">Perbaiki Perangkatmu</h5>
                <p class="card-text">Masukan Data dan Kerusakan perangkatmu agar kami dapat menemukan solusinya.</p>
                <a href="/posts/create" class="btn btn-dark navbar-custom"><i class="bi bi-hand-index-thumb"></i></a>
            </div>
        </div>
        </div>

        <div class="col-lg">
        <div class="card m-2" style="height:250px;" >
            <div class="card-body">
                <h5 class="card-title">Contact Teknisi</h5>
                <p class="card-text">Chat dengan Teknisi.</p>
                <a href="/posts" class="btn btn-dark navbar-custom"><i class="bi bi-hand-index-thumb"></i></a>
            </div>
        </div>
        </div>
      
        <div class="col-lg">
        <div class="card m-2" style="height:250px;" >
            <div class="card-body">
                <h5 class="card-title">Daftar Sparepart & Perkiraan Harga</h5>
                <p class="card-text">Anda dapat melihat daftar harga sparepart setiap brand di sini.</p>
                <a href="/sparepart" class="btn btn-dark navbar-custom"><i class="bi bi-hand-index-thumb"></i></a>
            </div>
        </div>
        </div>
        
        <div class="col-lg">
        <div class="card m-2" style="height:250px;" >
            <div class="card-body">
                <h5 class="card-title">Daftar Brand</h5>
                <p class="card-text">Daftar Brand yang kami support.</p>
                <a href="/brand" class="btn btn-dark navbar-custom"><i class="bi bi-hand-index-thumb"></i></a>
            </div>
        </div>
        </div>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tkiphone')): ?>
    

        <div class="col-lg">
            <div class="card m-2" style="height:250px;" >
                <div class="card-body">
                    <h5 class="card-title">Daftar Perangkat Iphone</h5>
                    <p class="card-text">Daftar User yang menginput perangkat Iphone.</p>
                    <a href="/categories/iphone" class="btn btn-dark navbar-custom"><i class="bi bi-hand-index-thumb"></i></a>
                </div>
            </div>
            </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tkxiaomi')): ?>
                
            
            <div class="col-lg">
                <div class="card m-2" style="height:250px;" >
                    <div class="card-body">
                        <h5 class="card-title">Daftar perangkat Xiaomi</h5>
                        <p class="card-text">Daftar User yang menginput perangkat Xiaomi.</p>
                        <a href="/categories/xiaomi" class="btn btn-dark navbar-custom"><i class="bi bi-hand-index-thumb"></i></a>
                    </div>
                </div>
                </div>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tksamsung')): ?>
                <div class="col-lg">
                    <div class="card m-2" style="height:250px;" >
                        <div class="card-body">
                            <h5 class="card-title">Daftar Perangkat Samsung</h5>
                            <p class="card-text">Daftar Brand yang kami support.</p>
                            <a href="/categories/samsung" class="btn btn-dark navbar-custom"><i class="bi bi-hand-index-thumb"></i></a>
                        </div>
                    </div>
                    </div>
                    <?php endif; ?>
    </div>


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\repairapid\repair-rapid\resources\views/dashboard/index.blade.php ENDPATH**/ ?>